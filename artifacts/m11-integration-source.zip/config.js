// v0.9 P0. Legacy settings remain explicit for regression and controlled A/B.
import { ECOLOGY_SHAPES } from './ecology-defs.js';
import {ADVANCED_SHAPES} from './advanced-defs.js';
import { EXPANSION_SKILLS } from './expansion-defs.js';
export const CONFIG = {
  width: 960, height: 540,
  arena: { left: 32, right: 928, top: 78, bottom: 512 },
  seed: 31415, duration: 20, directDamage: 3, attackInterval: .20,
  motion: { maxDrift: 6, starDrift: 4, maxSpeed: 16, periodMin: 3, periodMax: 6, rotationMin: 10, rotationMax: 35, starRotationMin: 6, starRotationMax: 18, tutorialHold: .4, contactTolerance: 1e-6, contactIterations: 256 },
  refinery: { rate: .06, tokens: 10, animationSeconds: 1.2, slots: [{ multiplier: .8, weight: 15 }, { multiplier: 1, weight: 35 }, { multiplier: 1.1, weight: 30 }, { multiplier: 1.3, weight: 15 }, { multiplier: 1.6, weight: 5 }] },
  step: 1 / 60, maxCatchUp: 8, spawnInterval: .2, spawnBatch: 3,
  spawnGrace: .15, spawnAttempts: 80, spawnGap: 12, clusterChance: .6,
  clusterMin: 65, clusterMax: 125, trajectoryMargin: 15,
  shard: { speed: 700, range: 180, rangePerLevel: 50, maxLife: .5, lifePadding: .02, bounces: 1, radius: 3 },
  smallShard: { damage: 1, range: 90, life: .15, splitAngle: 35 * Math.PI / 180 },
  inheritance: { radius: 45, damage: 1 },
  propagation: { delay: .03, squareSpeed: 650, starSpeed: 720, tailLife: .06 },
  impact: { radius: 42, damage: 1 },
  crushSpeed: { perLevel: .02, minimum: .14 },
  photonBoostPerLevel: .10,
  combo: { cooldown: .25, popupCap: 6, stages: {
    5: { label: 'CASCADE', color: '#6ADFEF', life: .45 },
    10: { label: 'OVERLOAD', color: '#C7ADFF', life: .55 },
    20: { label: 'SHARD STORM', color: '#FFD884', life: .65 }
  } },
  modifiers: { chargedCap: 2, chargedRadius: 1.25, chargedBonus: 1.20, crackedHP: .5,
    chances: [{ threshold: 0, cracked: 0, charged: 0 }, { threshold: 12, cracked: .10, charged: 0 }, { threshold: 30, cracked: .10, charged: .05 }, { threshold: 55, cracked: .12, charged: .08 }, { threshold: 90, cracked: .12, charged: .08 }] },
  variety: {
    radiusMin: 13, radiusMax: 21, minHitRadius: 16,
    triangle: { aspectMin: .85, aspectMax: 1.16, radialJitter: .10 },
    square: { aspectMin: .82, aspectMax: 1.18, vertexJitter: .08 },
    pentagon: { radialJitter: .11, angleJitter: Math.PI / 30 },
    star: { innerMin: .42, innerMax: .58, radialJitter: .07 },
    palettes: ['matte', 'bright', 'deep'], patterns: ['none', 'inset', 'split-line', 'center-core'],
    lightness: [39, 54, 24], saturation: 54, saturationJitter: 12, alphaMin: .32, alphaMax: .48
  },
  patterns: { clusterWeight: 35, arcWeight: 25, bridgeWeight: 20, clusterMin: 65, clusterMax: 110, arcSpacingMin: 50, arcSpacingMax: 90, neighbourMin: 65, neighbourMax: 115, starAnchorChance: .35 },
  amplifierRadius: 15, enhancedHP: 2, enhancedReward: 1.5,
  caps: { shards: 150, depth: 10, events: 400, particles: 240, visuals: 100, clickRings: 24, waves: 64, scheduled: 1024, tickIterations: 512 },
  visual: { flash: .055, debrisLife: .2, deathLife: .22, ringLife: .15, knockback: 18, knockbackLife: .18, guideLife: 3, starParticles: 10, clickLife: .12, clickStart: 8, clickEnd: 26, missLife: .07, missEnd: 12, recoilLife: .10, recoilScale: 1.08, clickDebrisLife: .15 },
  shapes: {
    triangle: { hp: 3, bonus: 5, radius: 22, color: '#6ADFEF', hue: 188, sides: 3, shardDamage: 3 },
    square: { hp: 4, bonus: 8, radius: 24, color: '#F4A6D2', hue: 326, sides: 4, areaRadius: 90, areaDamage: 2 },
    pentagon: { hp: 5, bonus: 12, radius: 25, color: '#C7ADFF', hue: 259, sides: 5, shardDamage: 3, splitAngle: Math.PI / 4 },
    star: { hp: 9, bonus: 40, radius: 29, color: '#FFD884', hue: 42, sides: 10, innerRatio: .47, areaRadius: 145, areaDamage: 5 },
    hex: {hp:8,bonus:20,radius:25,color:'#90e3ab',hue:144,sides:6,special:true,rank:2,tier:2,chance:.06,cap:3,drift:4},
    reactor: {hp:12,bonus:35,radius:27,color:'#ffad73',hue:25,sides:8,special:true,rank:3,tier:3,chance:.03,cap:2},
    ancient: {hp:30,bonus:120,radius:38,color:'#d7bdff',hue:265,sides:32,special:true,rank:4,tier:4,chance:.006,cap:1,runCap:2,drift:0},
    ...Object.fromEntries(Object.entries(ADVANCED_SHAPES).map(([id,d])=>[id,{...d,special:true,ecology:true,advanced:true}])),
    ...Object.fromEntries(Object.entries(ECOLOGY_SHAPES).map(([id,d])=>[id,{...d,special:true,ecology:true}]))
  },
  specialEffects: { ward:{radius:85,targets:2,reduction:1,releaseDelay:.03,releaseSpeed:650,failsafe:.25},reactor:[{hp:6,delay:.03,radius:75,damage:2},{hp:0,delay:.11,radius:110,damage:3}],ancient:{thresholds:[22,15,7],delay:.03,shards:2,shardDamage:1,shardRange:90,radius:60,damage:1,catalyst:2},tetherChance:.08 },
  legacyTiers: [
    { threshold: 0, target: 12, weights: [.65, .35, 0, 0], enhanced: 0 },
    { threshold: 12, target: 16, weights: [.45, .35, .2, 0], enhanced: 0 },
    { threshold: 30, target: 20, weights: [.4, .3, .2, .1], enhanced: 0 },
    { threshold: 55, target: 24, weights: [.35, .3, .2, .15], enhanced: .2 },
    { threshold: 90, target: 28, weights: [.35, .3, .2, .15], enhanced: .2 },
    { threshold: 140, target: 32, weights: [.35, .3, .2, .15], enhanced: .3 }
  ],
  tiers: [
    { threshold: 0, target: 12, weights: [.65, .35, 0, 0], enhanced: 0, cracked: 0, charged: 0 },
    { threshold: 15, target: 15, weights: [.45, .35, .20, 0], enhanced: 0, cracked: .08, charged: 0 },
    { threshold: 45, target: 18, weights: [.40, .30, .20, .10], enhanced: 0, cracked: .10, charged: .04 },
    { threshold: 100, target: 21, weights: [.35, .30, .20, .15], enhanced: .08, cracked: .10, charged: .05 },
    { threshold: 200, target: 25, weights: [.35, .30, .20, .15], enhanced: .15, cracked: .12, charged: .08 },
    { threshold: 400, target: 28, weights: [.35, .30, .20, .15], enhanced: .20, cracked: .12, charged: .08 },
    { threshold: 750, target: 30, weights: [.35, .30, .20, .15], enhanced: .25, cracked: .12, charged: .08 }
  ],
  tutorial: { x: 480, y: 335, distance: 108, angle: -Math.PI / 2 },
  upgrades: {
    crushPower: { name: 'Crush Power', subtitle: '직접 공격력', baseCost: 60, max: 5, perLevel: 1 },
    shardPower: { name: 'Shard Power', subtitle: '주 파편 피해', baseCost: 90, max: 5, perLevel: 1 },
    shardRange: { name: 'Shard Range', subtitle: '파편 비행거리', baseCost: 70, max: 3 },
    chainAmplifier: { name: 'Chain Amplifier', subtitle: '충격파 · 폭발', baseCost: 130, max: 3, perLevel: 1 },
    extraTime: { name: 'Extra Time', subtitle: '플레이 시간', baseCost: 120, max: 6, perLevel: 2 },
    crushSpeed: { name: 'Crush Speed', subtitle: '홀드 공격 속도', baseCost: 150, max: 3 },
    impactPulse: { name: 'Impact Pulse', subtitle: '직접 타격 추가 파동', baseCost: 260, max: 1 },
    ricochetPlus: { name: 'Ricochet+', subtitle: '주 파편 반사 횟수', baseCost: 170, max: 2 },
    shardBloom: { name: 'Shard Bloom', subtitle: '고유 파편 추가', baseCost: 290, max: 2 },
    echoCatalyst: { name: 'Echo Catalyst', subtitle: '계승 피해 강화', baseCost: 240, max: 2 },
    photonBoost: { name: 'Photon Boost', subtitle: '파괴 보너스 강화', baseCost: 180, max: 3 },
    precisionFracture: { name:'Precision Fracture',subtitle:'Cracked 직접 최종타 · 파편과 Raw',baseCost:180,max:2,rank:1,catalyst:[0,0] },
    yieldStabilizer: { name:'Yield Stabilizer',subtitle:'낮은 Refinery 슬롯 보정',baseCost:220,max:2,rank:1,catalyst:[0,0] },
    rareSeparator: { name:'Rare Separator',subtitle:'Core 보너스 · 첫 Core Catalyst',baseCost:350,max:2,rank:2,catalyst:[2,4] },
    fragmentRelay: { name:'Fragment Relay',subtitle:'주 파편 최종타 후 Relay',baseCost:520,max:2,rank:2,catalyst:[4,6] },
    kineticReach: { name:'Kinetic Reach',subtitle:'회전 원본 주 파편 거리',baseCost:420,max:2,rank:2,catalyst:[2,3] },
    resonanceLayer: { name:'Resonance Layer',subtitle:'Reactor → Charged 여진',baseCost:650,max:2,rank:3,catalyst:[6,8] },
    salvageScanner: { name:'Salvage Scanner',subtitle:'희귀 강조 · Core/Void 확률',baseCost:700,max:2,rank:3,catalyst:[6,8] },
    catalystChannel: { name:'Catalyst Channel',subtitle:'Ancient 표식 직접 파괴 파편',baseCost:1400,max:1,rank:4,catalyst:[24] }
  },
  // Positions and prerequisite edges are declarative. Existing balances stay above.
  skillDefinitions: [
    { id: 'crushPower', branch: 'destroy', position: { col: 0, row: 1 }, prerequisites: [] },
    { id: 'crushSpeed', branch: 'destroy', position: { col: 0, row: 2 }, prerequisites: [{ id: 'crushPower', minLevel: 1 }] },
    { id: 'impactPulse', branch: 'destroy', position: { col: 0, row: 3 }, prerequisites: [{ id: 'crushPower', minLevel: 2 }] },
    { id: 'shardPower', branch: 'cascade', position: { col: 1, row: 1 }, prerequisites: [] },
    { id: 'shardRange', branch: 'cascade', position: { col: 1, row: 2 }, prerequisites: [{ id: 'shardPower', minLevel: 1 }] },
    { id: 'ricochetPlus', branch: 'cascade', position: { col: 1, row: 3 }, prerequisites: [{ id: 'shardRange', minLevel: 1 }] },
    { id: 'shardBloom', branch: 'cascade', position: { col: 1, row: 4 }, prerequisites: [{ id: 'shardPower', minLevel: 2 }] },
    { id: 'chainAmplifier', branch: 'reaction', position: { col: 2, row: 1 }, prerequisites: [] },
    { id: 'echoCatalyst', branch: 'reaction', position: { col: 2, row: 2 }, prerequisites: [{ id: 'chainAmplifier', minLevel: 1 }] },
    { id: 'extraTime', branch: 'utility', position: { col: 3, row: 1 }, prerequisites: [] },
    { id: 'photonBoost', branch: 'utility', position: { col: 3, row: 2 }, prerequisites: [{ id: 'extraTime', minLevel: 1 }] },
    {id:'precisionFracture',branch:'destroy',position:{col:0,row:4},prerequisites:[{id:'crushPower',minLevel:2}]},
    {id:'fragmentRelay',branch:'cascade',position:{col:1,row:5},prerequisites:[{id:'shardPower',minLevel:2}]},
    {id:'kineticReach',branch:'cascade',position:{col:1,row:6},prerequisites:[{id:'shardRange',minLevel:1}]},
    {id:'resonanceLayer',branch:'reaction',position:{col:2,row:3},prerequisites:[{id:'chainAmplifier',minLevel:2}]},
    {id:'salvageScanner',branch:'utility',position:{col:3,row:3},prerequisites:[{id:'photonBoost',minLevel:1}]},
    {id:'yieldStabilizer',branch:'refinery',position:{col:4,row:1},prerequisites:[]},
    {id:'rareSeparator',branch:'refinery',position:{col:4,row:2},prerequisites:[{id:'yieldStabilizer',minLevel:1}]},
    {id:'catalystChannel',branch:'legacy',position:{col:4,row:4},prerequisites:[{id:'rareSeparator',minLevel:1},{id:'resonanceLayer',minLevel:1}]}
  ],
  discovery: [
    { threshold: 0, unlock: '기본 4종 · 기존 11스킬' },
    { threshold: 300, unlock: 'Prism · Precision Fracture · Yield Stabilizer' },
    { threshold: 1200, unlock: 'Core · Catalyst · Hex (Run 45킬) · 신규 파편/가공' },
    { threshold: 3500, unlock: 'Reactor (Run 100킬) · Resonance · Scanner' },
    { threshold: 8000, unlock: 'Void · Ancient (Run 200킬) · Catalyst Channel' }
  ],
  ore: { common: { rank: 0, chance: 0, raw: 0, catalyst: 0, symbol: '' }, prism: { rank: 1, chance: .08, raw: 15, catalyst: 0, symbol: '◇' }, core: { rank: 2, chance: .02, raw: 60, catalyst: 1, symbol: '◈' }, void: { rank: 4, chance: .005, raw: 180, catalyst: 2, symbol: '✦' } },
  relics: {
    ricochetCoil:{name:'Ricochet Coil',rank:1,counter:'mainShardWallBounces',target:30,photon:250,catalyst:4,bounces:1,rangePenalty:40,minRange:120,description:'주 파편 반사 +1 · 거리 -40px (최소120)'},
    waveCondenser:{name:'Wave Condenser',rank:1,counter:'nativeWaveKills',target:50,photon:360,catalyst:6,damage:1,radiusMultiplier:.85,description:'Square/Star 고유 피해 +1 · 반경 ×.85 반올림'},
    cracklingEdge:{name:'Crackling Edge',rank:1,counter:'directCrackedKills',target:30,photon:420,catalyst:10,directPenalty:1,delay:.03,radius:55,damage:1,description:'Cracked 직접 최종타 뒤 .03초 보조55px/1 · 직접 피해 -1 (최소1)'},
    hexSiphon:{name:'Hex Siphon',rank:2,counter:'wardReleasesFromHexDeath',target:25,photon:700,catalyst:16,chargeCap:2,expires:4,consumptionCap:6,damage:1,description:'Hex 해제 충전 최대2 · 다음 성공 직접 피해 +1 · 4초 만료/Run6소비'},
    reactorGovernor:{name:'Reactor Governor',rank:3,counter:'reactorStageWaveExecuted',target:40,photon:900,catalyst:18,damage:1,delayPenalty:.08,description:'Reactor 단계 피해 +1 · 지연 +.08초 (.11/.19초)'},
    ancientResonator:{name:'Ancient Resonator',rank:4,counter:'ancientKills',target:4,photon:1600,catalyst:32,damage:1,range:75,description:'Ancient 각 단계 보조 파편1 / 피해1 / 75px · 다른 도형 미적용'}
  },
  meta: {version:1,eventLogCap:512,relicSlots:2,contractSlots:3,contractTargets:[1,2,4],contractPhoton:[1,1.5,2],contractCatalyst:[1,2,3],offerCount:3,anomalyPhotonCap:60},
  contracts: {
    preciseClicks:{name:'Precision Duty',rank:0,counter:'directKills',target:80,photon:75,catalyst:0},
    chainHunter:{name:'Chain Hunter',rank:0,counter:'chain10',target:5,photon:100,catalyst:0},
    fragmentRoute:{name:'Fragment Route',rank:1,counter:'primaryShardKills',target:90,photon:130,catalyst:0},
    waveTactic:{name:'Wave Tactic',rank:1,counter:'nativeWaveKills',target:80,photon:120,catalyst:0},
    crackedCleanup:{name:'Crackdown',rank:1,counter:'directCrackedKills',target:25,photon:110,catalyst:0},
    hexLiberator:{name:'Hex Liberator',rank:2,counter:'wardReleasesFromHexDeath',target:18,photon:175,catalyst:2},
    coreCollector:{name:'Core Collector',rank:2,counter:'coreOreKills',target:12,photon:145,catalyst:2},
    reactorEngineer:{name:'Reactor Engineer',rank:3,counter:'reactorStageWaveExecuted',target:25,photon:200,catalyst:3},
    anomalyPilot:{name:'Anomaly Pilot',rank:2,counter:'anomalyWins',target:4,photon:180,catalyst:2},
    ancientHunter:{name:'Ancient Hunter',rank:4,counter:'ancientKills',target:3,photon:280,catalyst:6}
  },
  anomalies: {
    fastOrbit:{name:'Fast Orbit',rank:0,rate:.10,counter:'movingDirectKills',target:12,motion:1.5,description:'드리프트/회전 속도 ×1.5 (기존 상한) · 움직이는 도형 직접12파괴'},
    denseField:{name:'Dense Field',rank:0,rate:.08,counter:'chain15',target:1,density:1.2,aliveCap:32,description:'Tier 밀도 ×1.20 (최대32) · 한 Chain15 달성'},
    fragileMatter:{name:'Fragile Matter',rank:1,rate:.10,counter:'directCrackedKills',target:6,crackedAdd:.08,description:'비Enhanced Cracked +8%p · Cracked 직접6파괴'},
    overcharge:{name:'Overcharge',rank:1,rate:.11,counter:'chargedOrReactorKills',target:3,chargedMultiplier:1.75,reactorMultiplier:1.5,description:'Charged 확률 ×1.75/상한2 · Rank3 Reactor ×1.5 · Charged/Reactor3파괴'},
    fortified:{name:'Fortified',rank:2,rate:.12,counter:'wardReleasesFromHexDeath',target:2,hexAdd:.04,wardReduction:2,description:'Hex 확률 +4%p · Ward 피해감소2 · Hex 사망 Ward2해제'},
    unstableCore:{name:'Unstable Core',rank:3,rate:.15,counter:'reactorStageWaveExecuted',target:3,alternateCounter:'ancientKills',alternateTarget:1,reactorMultiplier:1.5,ancientMultiplier:3,description:'Reactor ×1.5/Rank4 Ancient ×3 (상한 유지) · 실제 Reactor파동3 또는 Ancient1파괴'}
  },
  costGrowth: 1.6, saveVersion: 8, storageKey: 'shard-storm-v1', historyLimit: 20,
  dev: { grant: 1000, minDuration: 1, maxDuration: 90 },
  options: { secondaryTraitsEnabled:true,combatFXEnabled:true,screenShakeEnabled:true,reducedMotionEnabled:false,oreEnabled:true,inheritance: true, ricochet: true, sequentialPropagation: true, visualVariety: true, damageVFX: true, sound: false, comboFeedback: true, modifiers: true, modifierVisuals: true, motionEnabled: true, refineryEnabled: true }
};

Object.assign(CONFIG.upgrades, EXPANSION_SKILLS);
CONFIG.skillDefinitions.push(...Object.values(EXPANSION_SKILLS).map(d=>({id:d.id,branch:d.branch,position:d.position,prerequisites:d.prerequisites,implemented:true})));
